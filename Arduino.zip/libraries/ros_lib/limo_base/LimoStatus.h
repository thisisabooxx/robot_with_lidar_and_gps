#ifndef _ROS_limo_base_LimoStatus_h
#define _ROS_limo_base_LimoStatus_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"
#include "std_msgs/Header.h"

namespace limo_base
{

  class LimoStatus : public ros::Msg
  {
    public:
      typedef std_msgs::Header _header_type;
      _header_type header;
      typedef uint8_t _vehicle_state_type;
      _vehicle_state_type vehicle_state;
      typedef uint8_t _control_mode_type;
      _control_mode_type control_mode;
      typedef float _battery_voltage_type;
      _battery_voltage_type battery_voltage;
      typedef uint16_t _error_code_type;
      _error_code_type error_code;
      typedef uint8_t _motion_mode_type;
      _motion_mode_type motion_mode;

    LimoStatus():
      header(),
      vehicle_state(0),
      control_mode(0),
      battery_voltage(0),
      error_code(0),
      motion_mode(0)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const override
    {
      int offset = 0;
      offset += this->header.serialize(outbuffer + offset);
      *(outbuffer + offset + 0) = (this->vehicle_state >> (8 * 0)) & 0xFF;
      offset += sizeof(this->vehicle_state);
      *(outbuffer + offset + 0) = (this->control_mode >> (8 * 0)) & 0xFF;
      offset += sizeof(this->control_mode);
      offset += serializeAvrFloat64(outbuffer + offset, this->battery_voltage);
      *(outbuffer + offset + 0) = (this->error_code >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->error_code >> (8 * 1)) & 0xFF;
      offset += sizeof(this->error_code);
      *(outbuffer + offset + 0) = (this->motion_mode >> (8 * 0)) & 0xFF;
      offset += sizeof(this->motion_mode);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer) override
    {
      int offset = 0;
      offset += this->header.deserialize(inbuffer + offset);
      this->vehicle_state =  ((uint8_t) (*(inbuffer + offset)));
      offset += sizeof(this->vehicle_state);
      this->control_mode =  ((uint8_t) (*(inbuffer + offset)));
      offset += sizeof(this->control_mode);
      offset += deserializeAvrFloat64(inbuffer + offset, &(this->battery_voltage));
      this->error_code =  ((uint16_t) (*(inbuffer + offset)));
      this->error_code |= ((uint16_t) (*(inbuffer + offset + 1))) << (8 * 1);
      offset += sizeof(this->error_code);
      this->motion_mode =  ((uint8_t) (*(inbuffer + offset)));
      offset += sizeof(this->motion_mode);
     return offset;
    }

    virtual const char * getType() override { return "limo_base/LimoStatus"; };
    virtual const char * getMD5() override { return "89a12362fe9a1bc68d82a887b7cca0f7"; };

  };

}
#endif
