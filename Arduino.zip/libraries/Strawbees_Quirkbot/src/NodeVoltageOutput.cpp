#include "NodeVoltageOutput.h"

VoltageOutput::VoltageOutput():
in(light){
}
VoltageOutput::~VoltageOutput(){}
