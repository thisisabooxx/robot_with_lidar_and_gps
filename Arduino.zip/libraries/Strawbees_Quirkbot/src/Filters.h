#ifndef Filters_h_
#define Filters_h_

#include "FilterMedian.h"
#include "FilterLowPass.h"
#include "FilterLower.h"
#include "FilterUpper.h"

#endif
