#include <ros/ros.h>
#include <tf/transform_broadcaster.h>
#include <nav_msgs/Odometry.h>
#include <std_msgs/Float32.h> 
#include <math.h>

#define RovWid 1.35 // 0.57		// unkwown*
#define Pi 3.141592865358979		// Pi
#define TicksPerRev 620		// Ticks per Revolutions ( TPR )
#define WheelDia 0.10			// Wheel Diameter
//#define Radius 0.055			// Wheel Radius
/*float dl = 0;
float dr = 0;
float dc = 0;
float dt = 0;
float dth = 0;
float dx = 0;
float dy = 0;
float iccX = 0;
float iccY = 0;*/

float left,right; //declare global variables to hold incoming data

void CallbackLeft(const std_msgs::Float32::ConstPtr& msg)
{
  //ROS_INFO("Left ticks [%f]", msg->data);
  left = msg->data;
}

void CallbackRight(const std_msgs::Float32::ConstPtr& msg)
{
  //ROS_INFO("Right ticks [%f]", msg->data);
  right = msg->data;
}

int main(int argc, char** argv){
    ros::init(argc, argv, "odometry_publisher");

    ros::NodeHandle n;
    ros::Publisher odom_pub = n.advertise<nav_msgs::Odometry>("odom", 50);
    ros::Subscriber sub1 = n.subscribe("ticks_left", 100, CallbackLeft);
    ros::Subscriber sub2 = n.subscribe("ticks_right", 100, CallbackRight);
    tf::TransformBroadcaster odom_broadcaster;

    double vx = 0.0;
    double vy = 0.0;
    double vth = 0.0;

    float DeltaLeft = 0;
    float DeltaRight = 0;
    float PreviousRight = 0;
    float PreviousLeft = 0;

    float Theta = 0;
    float X = 0;
    float Y = 0;

    float Circum, DisPerTick, expr1,right_minus_left;

    ros::Time current_time, last_time;
    current_time = ros::Time::now();
    last_time = ros::Time::now();

    ros::Rate r(5);
    ROS_INFO("Node started");
    Circum = Pi * WheelDia;		// circumference of a circle = 2*pi*R
    DisPerTick = Circum / TicksPerRev;
	
    while(n.ok()){

          ros::spinOnce();               // check for incoming messages
          current_time = ros::Time::now();

          DeltaRight = (right - PreviousRight) * DisPerTick;
          DeltaLeft = (left - PreviousLeft) * DisPerTick;
          PreviousRight = right;
          PreviousLeft = left;


          if (DeltaLeft == DeltaRight){
                X += DeltaLeft * cos(Theta);
                Y += DeltaLeft * sin(Theta);
          }
          else{
                 expr1 = RovWid * 2 * (DeltaRight + DeltaLeft)/ 2.0 / (DeltaRight - DeltaLeft);
                 right_minus_left = DeltaRight - DeltaLeft;
                 X += 0.195*expr1 * (sin(right_minus_left / (RovWid *2) + Theta) - sin(Theta));	// 0.3*
                 Y -= 0.195*expr1 * (cos(right_minus_left / (RovWid *2) + Theta) - cos(Theta));
                 Theta += right_minus_left / (RovWid *2);
                 Theta = Theta - ((2 * Pi) * floor( Theta / (2 * Pi)));	
          }

          ROS_INFO("X [%f]", X);
          ROS_INFO("Y [%f]", Y);
          ROS_INFO("Theta [%f]", Theta);
          ROS_INFO("\n");

          geometry_msgs::Quaternion odom_quat = tf::createQuaternionMsgFromYaw(Theta);

          geometry_msgs::TransformStamped odom_trans;
          odom_trans.header.stamp = current_time;
          odom_trans.header.frame_id = "odom";
          odom_trans.child_frame_id = "base_link";

          odom_trans.transform.translation.x = X;
          odom_trans.transform.translation.y = Y;
          odom_trans.transform.translation.z = 0.0;
          odom_trans.transform.rotation = odom_quat;

          odom_broadcaster.sendTransform(odom_trans);

          nav_msgs::Odometry odom;
          odom.header.stamp = current_time;
          odom.header.frame_id = "odom";

          odom.pose.pose.position.x = X;
          odom.pose.pose.position.y = Y;
          odom.pose.pose.position.z = 0.0;
          odom.pose.pose.orientation = odom_quat;

          odom.child_frame_id = "base_link";
          odom.twist.twist.linear.x = 0;
          odom.twist.twist.linear.y = 0;
          odom.twist.twist.angular.z = 0;

          odom_pub.publish(odom);

          last_time = current_time;
          r.sleep();
         }
      }    
         
        
    /*while(n.ok()){

          ros::spinOnce();               // check for incoming messages
          current_time = ros::Time::now();
          DeltaLeft  = left - PreviousLeft;
          DeltaRight = right - PreviousRight;
          
          PreviousRight = right;
          PreviousLeft = left;
          
          dl = 2 * Pi * Radius * DeltaLeft / TicksPerRev;
          dr = 2 * Pi * Radius * DeltaRight / TicksPerRev;
          
          dc = (dl + dr) / 2;
          dt = current_time - last_time;
          dth = (dr - dl) / RovWid;


          if (DeltaLeft == DeltaRight){
                dx = dr * cos(Theta);
                dy = dr * sin(Theta);
          }
          else{
                 
                 Radius = dc/dth;
                 
                 iccX = x-Radius*sin(Theta);
                 iccY = y+Radius*cos(Theta);
                 
                 dx = cos(dth) * (x-iccX) - sin(dth) * (y-iccY) + iccX - x;
                 dy = sin(dth) * (x-iccX) - cos(dth) * (y-iccY) + iccY - y;
          
          }
          
          X = X+dx;
          Y = Y+dy;
          Theta = (Theta+dth) % (2*Pi);

          ROS_INFO("X [%f]", X);
          ROS_INFO("Y [%f]", Y);
          ROS_INFO("Theta [%f]", Theta);
          ROS_INFO("\n");

          geometry_msgs::Quaternion odom_quat = tf::createQuaternionMsgFromYaw(Theta);

          geometry_msgs::TransformStamped odom_trans;
          odom_trans.header.stamp = current_time;
          odom_trans.header.frame_id = "odom";
          odom_trans.child_frame_id = "base_link";

          odom_trans.transform.translation.x = X;
          odom_trans.transform.translation.y = Y;
          odom_trans.transform.translation.z = 0.0;
          odom_trans.transform.rotation = odom_quat;

          odom_broadcaster.sendTransform(odom_trans);

          nav_msgs::Odometry odom;
          odom.header.stamp = current_time;
          odom.header.frame_id = "odom";

          odom.pose.pose.position.x = X;
          odom.pose.pose.position.y = Y;
          odom.pose.pose.position.z = 0.0;
          odom.pose.pose.orientation = odom_quat;

          odom.child_frame_id = "base_link";
          odom.twist.twist.linear.x = 0;
          odom.twist.twist.linear.y = 0;
          odom.twist.twist.angular.z = 0;

          odom_pub.publish(odom);

          last_time = current_time;
          r.sleep();
         }
    }*/
