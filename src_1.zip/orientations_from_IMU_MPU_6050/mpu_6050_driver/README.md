# mpu_6050_driver
ROS driver for the MPU-6050 IMU
