import cv2
import pandas as pd
import numpy as np
from time import sleep

data_path = 'data.csv'                                                      # read data from csv file -> delete
data = pd.read_csv(data_path, names=['LATITUDE', 'LONGITUDE'], sep=',')     # read data from csv file -> delete
gps_data = tuple(zip(data['LATITUDE'].values, data['LONGITUDE'].values))    # read data from csv file -> delete

img = cv2.imread('map.png', -1)     # read map image from file
cv2.imshow('Map', img)              # show map
cv2.waitKey(2)                      # wait for 2 ms before next step
img_points = []     # initial position array
points = (13.65200, 100.49142, 13.64950, 100.49362)         # Two coordinates of the map (upper left, lower right)
ratio_x = float(img.shape[1]) / (points[3] - points[1])     # calculate X-axis ratio for converting longtitude
ratio_y = float(img.shape[0]) / (points[0] - points[2])     # calculate Y-axis ratio for converting latitude


#while True:
for d in gps_data:    
    #lat = float(input("latitude: "))       # input latitude from keyboard -> delete
    #long = float(input("longitude: "))     # input longitude from keyboard -> delete
    lat = d[0]      # current latitude -> gpsd.fix.latitude
    long = d[1]     # current longitude -> gpsd.fix.longitude
   
    if lat <= points[0] and lat >= points[2] and long <= points[3] and long >= points[1]:   # check position in map range
        ynew_pos = img.shape[0] - int((lat - points[2]) * ratio_y)                          # convert latitude to Y-axis in pixel
        xnew_pos = int((long - points[1]) * ratio_x)                                        # convert longtitude to X-axis in pixel
       
        img_points.append([xnew_pos,ynew_pos])      # collect position
      
        pts = np.array(img_points, np.int32)        # build position array
        pts = pts.reshape((-1,1,2))

        cv2.polylines(img,[pts],False,(255,0,0))    # draw line
        cv2.imshow('Map', img)                      # show map with routh
        cv2.waitKey(2)                              # wait for 2 ms before next step
               
    else:
       print("Out of range")    # current position is out of map range


cv2.waitKey(0)              # wait till any key is pressed
cv2.destroyAllWindows()     # close window