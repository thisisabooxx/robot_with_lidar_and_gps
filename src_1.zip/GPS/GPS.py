
#! /usr/bin/python
# Written by Dan Mandle http://dan.mandle.me September 2012
# License: GPL 2.0
# Updated by wolfg1969 https://guoyong.dev May 2020
 
import os
from gps import *
from time import *
import time
import threading

from time import sleep
import cv2
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image, ImageDraw
 
gpsd = None #seting the global variable
 
os.system('clear') #clear the terminal (optional)
 
class GpsPoller(threading.Thread):
  def __init__(self):
    threading.Thread.__init__(self)
    global gpsd #bring it in scope
    gpsd = gps(mode=WATCH_ENABLE) #starting the stream of info
    self.current_value = None
    self.running = True #setting the thread running to true
 
  def run(self):
    global gpsd
    while gpsp.running:
      gpsd.next() #this will continue to loop and grab EACH set of gpsd info to clear the buffer
 
if __name__ == '__main__':
  gpsp = GpsPoller() # create the thread
  try:
    gpsp.start() # start it up
    while True:
      # It may take a second or two to get good data
      # print(gpsd.fix.latitude,', ',gpsd.fix.longitude,'  Time: ',gpsd.utc)
 
      os.system('clear')
 
      print
      print(gpsd.fix.latitude,', ',gpsd.fix.longitude,'  Time: ',gpsd.utc)
      print(' GPS reading')
      print('----------------------------------------')
      print('latitude    ', gpsd.fix.latitude)
      print('longitude   ', gpsd.fix.longitude)
      print('time utc    ', gpsd.utc, ' + ', gpsd.fix.time)
      
      ##float_value = 1.99
      ##string_value = str(float_value)
      str_lat  = str(gpsd.fix.latitude)
      str_long = str(gpsd.fix.longitude)
      str_time = str(gpsd.utc)
      
      if((str_lat != 'nan') and (str_long != 'nan') and (str_lat != '0.0') and (str_long != '0.0')):   ## NaN , 0 cases------------
          lat_long_val = [str_lat +','+ str_long +'\n']
          with open('lat_long_val.txt', 'a') as f:
              f.writelines('\n'.join(lat_long_val))   

      time.sleep(0.8) #set to whatever

      ####################### pathPlotTest.py ############################

  img = cv2.imread('map.png', -1)     # read map image from file
  cv2.imshow('map', img)              # show map
  cv2.waitKey(2)                      # wait for 2 ms before next step
  img_points = []     # initial position array
  points = (13.65200, 100.49142, 13.64950, 100.49362)         # Two coordinates of the map (upper left, lower right)
  ratio_x = float(img.shape[1]) / (points[3] - points[1])     # calculate X-axis ratio for converting longtitude
  ratio_y = float(img.shape[0]) / (points[0] - points[2])     # calculate Y-axis ratio for converting latitude
  
  lat = gpsd.fix.latitude      # current latitude -> gpsd.fix.latitude
  long = gpsd.fix.longitude     # current longitude -> gpsd.fix.longitude
      if lat <= points[0] and lat >= points[2] and long <= points[3] and long >= points[1]:   # check position in map range
          ynew_pos = img.shape[0] - int((lat - points[2]) * ratio_y)                          # convert latitude to Y-axis in pixel
          xnew_pos = int((long - points[1]) * ratio_x)                                        # convert longtitude to X-axis in pixel
       
          img_points.append([xnew_pos,ynew_pos])      # collect position
      
          pts = np.array(img_points, np.int32)        # build position array
          pts = pts.reshape((-1,1,2))

          cv2.polylines(img,[pts],False,(255,0,0))    # draw line
          cv2.imshow('Map', img)                      # show map with routh
          cv2.waitKey(2)                              # wait for 2 ms before next step
               
      else:
         print("Out of range")    # current position is out of map range


  cv2.waitKey(0)              # wait till any key is pressed
  cv2.destroyAllWindows()     # close window
      
  ########################## ^C #############################
  except (KeyboardInterrupt, SystemExit): #when you press ctrl+c
    print("\nKilling Thread...")
    gpsp.running = False
    gpsp.join() # wait for the thread to finish what it's doing
    
    #df = pd.read_csv('lat_long_val.txt')
    #df.to_csv('data.csv', sep = ',')
    
  print("Done.\nExiting.")
  
